# Election_Analysis
1. Overview of Election Audit: Explain the purpose of this election audit analysis.

Inspite of submitting election audit results to the election commission, they requested to Seht and Tom some additional data to complete audit such as - 
-  The voter turnout for each county. In this we need to calculated total votes count. 
- The percentage of votes from each county out of the total count.
- The county with highest turnout. 

This calculated by using python , with some calculations and using for loop etc. 

2. Election-Audit Results: Using a bulleted list, address the following election outcomes. Use images or examples of your code as support where necessary.

How many votes were cast in this congressional election?

There were 369,711 votes cast in the election. 

Provide a breakdown of the number of votes and the percentage of total votes for each county in the precinct.

The no. of votes for each county is as given below. 

County Votes:
Jefferson : 10.5 % (38,855)
Denver : 82.8 % (306,055)
Arapahoe : 6.7 % (24,801)

Which county had the largest number of votes?

Denver county had largest no. of votes. 

Provide a breakdown of the number of votes and the percentage of the total votes each candidate received.

The no. of votes for each candidate is as below 

Charles Casper Stockham: 23.0% (85,213)
Diana DeGette: 73.8% (272,892)
Raymon Anthony Doane: 3.1% (11,606)

Which candidate won the election, what was their vote count, and what was their percentage of the total votes?

The winning candidate is Diana Degette. 
Winning Vote count : 272,892
winning Percentage : 73.8%

3. Election-Audit Summary: In a summary statement, provide a business proposal to the election commission on how this script can be used—with some modifications—for any election. Give at least two examples of how this script can be modified to be used for other elections.

The analysis work is done using python, visual studio code and Git with commiting changes. 
This will help us , to do analysis with in detail. Calculating percentage and total count and subcount. 
In this analysis , I will say that , there are chances of refactoring the same data code. And also we can include the charts into the data for better visual representation.  